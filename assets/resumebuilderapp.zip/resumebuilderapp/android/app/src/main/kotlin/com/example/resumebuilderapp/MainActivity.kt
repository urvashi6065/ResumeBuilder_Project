package com.example.resumebuilderapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
