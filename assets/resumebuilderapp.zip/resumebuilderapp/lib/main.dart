import 'package:flutter/material.dart';
import 'package:resumebuilderapp/Achievements.dart';
import 'package:resumebuilderapp/Contact%20Info.dart';
import 'package:resumebuilderapp/Declaration.dart';
import 'package:resumebuilderapp/Education.dart';
import 'package:resumebuilderapp/Experiences.dart';
import 'package:resumebuilderapp/Interest_Hobbies.dart';
import 'package:resumebuilderapp/Personal_Details.dart';
import 'package:resumebuilderapp/Projects.dart';
import 'package:resumebuilderapp/References.dart';
import 'package:resumebuilderapp/ResumeWorkSpace.dart';
import 'package:resumebuilderapp/Splash_Screen.dart';
import 'package:resumebuilderapp/Technical_Skills.dart';

import 'Carrier_Objective.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        '/': (context) =>SplashScreen(),
        '/homepage':(context)=>MyHomePage(title: 'Flutter Demo Home Page'),
        '/resumeworkspace': (context) =>ResumeWorkSpace(),
        '/contactinfo':(context)=>Contact_info(),
        '/carrierobjective':(context)=>CarrierObjective(),
        '/personaldetails':(context)=>PersonalDetails(),
        '/education':(context)=>Education(),
        '/experiences':(context)=>Experiences(),
        '/technicalskills':(context)=>TechnicalSkills(),
        '/interest/hobbies':(context)=>InterestHobbies(),
        '/projects':(context)=>Projects(),
        '/achievements':(context)=>Achievements(),
        '/references':(context)=>References(),
        '/declaration':(context)=>Declaration(),

      },
      initialRoute: '/',
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,

      theme: ThemeData(
        useMaterial3: false,
        primarySwatch: Colors.blue,
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});



  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {

      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Resume Builder',
          style: TextStyle(
            fontSize: 25,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 50.0),
        child: Center(
          child: Column(
            children: [
              Image(
                image: AssetImage('assets/box.png'),
                width: 60,
              ),
              SizedBox(height: 10,),
              Text(
                'No Resumes + Create new resume.',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
          Navigator.of(context).pushNamed( '/resumeworkspace');
        },
         child:  Icon(Icons.add,color: Colors.white,size: 50,),
      ),
    );
  }
}
