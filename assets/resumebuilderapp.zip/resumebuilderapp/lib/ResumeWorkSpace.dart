import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'Model class.dart';

class ResumeWorkSpace extends StatefulWidget {
  const ResumeWorkSpace({Key? key}) : super(key: key);

  @override
  State<ResumeWorkSpace> createState() => _ResumeWorkSpaceState();
}

class _ResumeWorkSpaceState extends State<ResumeWorkSpace> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: IconButton(
          icon: Icon(CupertinoIcons.back), onPressed: () {
            Navigator.of(context).pop();
        },
        ),
        centerTitle: true,
        title: Text(
          'Resume Workspace',
          style: TextStyle(
            fontSize: 25,
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: listdata.map((e) => Center(
            child: Column(
              children: [
                ListTile(
                  onTap: (){
                    Navigator.of(context).pushNamed(e.route);
                  },
                  leading: Image.asset(e.image,width: 35,),
                  title: Text(e.title,style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                  trailing: IconButton(
                    onPressed: (){},
                    icon: Icon(CupertinoIcons.forward),
                  ),
                ),
                Divider(color: Colors.grey,thickness: 1),
              ],
            ),
          ),
          ).toList(),
        ),
      ),
    );
  }
}
